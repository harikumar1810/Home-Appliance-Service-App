package com.example.home;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.io.ByteArrayOutputStream;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity8 extends AppCompatActivity {

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity8_main);

        dbHelper = new DBHelper(this);


        List<Provider2> providerList = dbHelper.getAllProviders();


        Collections.sort(providerList, new Comparator<Provider2>() {
            @Override
            public int compare(Provider2 p1, Provider2 p2) {
                return Float.compare(p2.getRating(), p1.getRating());
            }
        });


        LinearLayout row1 = findViewById(R.id.row1);
        LinearLayout row2 = findViewById(R.id.row2);
        LinearLayout row3 = findViewById(R.id.row3);

        for (Provider2 provider : providerList) {
            CardView cardView = new CardView(this);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            cardParams.setMargins(10, 10, 10, 10);
            cardView.setLayoutParams(cardParams);


            cardView.setCardElevation(8);
            cardView.setRadius(16);

            LinearLayout cardLayout = new LinearLayout(this);
            cardLayout.setOrientation(LinearLayout.HORIZONTAL);

            ImageView imageView = new ImageView(this);
            imageView.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.MATCH_PARENT, 1));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Bitmap bitmap = BitmapFactory.decodeByteArray(provider.getImage(), 0, provider.getImage().length);
            imageView.setImageBitmap(bitmap);

            LinearLayout textLayout = new LinearLayout(this);
            textLayout.setOrientation(LinearLayout.VERTICAL);
            textLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 2));
            textLayout.setPadding(16, 16, 16, 16);

            TextView textView1 = new TextView(this);
            textView1.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            textView1.setText(provider.getName());
            textView1.setTextSize(25);
            textView1.setGravity(Gravity.CENTER);
            textView1.setTypeface(null, Typeface.BOLD);

            TextView textView2 = new TextView(this);
            textView2.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            textView2.setText(provider.getPhoneNumber());
            textView2.setTextSize(20);
            textView2.setGravity(Gravity.CENTER);

            RatingBar ratingBar = new RatingBar(this);
            ratingBar.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            ratingBar.setNumStars(5);
            ratingBar.setStepSize(0.5f);
            ratingBar.setRating(provider.getRating());

            textLayout.addView(textView1);
            textLayout.addView(textView2);
            textLayout.addView(ratingBar);

            cardLayout.addView(textLayout);
            cardLayout.addView(imageView);

            cardView.addView(cardLayout);

            if (row1.getChildCount() < 1) {
                row1.addView(cardView);
            } else if (row2.getChildCount() < 1) {
                row2.addView(cardView);
            } else {
                row3.addView(cardView);
            }

            final Provider2 finalProvider = provider;
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity8.this);
                    builder.setMessage("Do you want to book?")
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    Intent intent = new Intent(MainActivity8.this, MainActivity11.class);
                                    intent.putExtra("provider_name", finalProvider.getName());
                                    intent.putExtra("provider_phone", finalProvider.getPhoneNumber());


                                    EditText nameEditText = findViewById(R.id.editTextText);
                                    String customerName = nameEditText.getText().toString().trim();

                                    EditText addressEditText = findViewById(R.id.editTextText2);
                                    String customerAddress = addressEditText.getText().toString().trim();

                                    EditText phoneEditText = findViewById(R.id.editTextPhone);
                                    String customerPhone = phoneEditText.getText().toString().trim();

                                    EditText dateEditText = findViewById(R.id.editTextDate);
                                    String date = dateEditText.getText().toString().trim();

                                    EditText timeEditText = findViewById(R.id.editTextTime);
                                    String time = timeEditText.getText().toString().trim();


                                    intent.putExtra("customer_name", customerName);
                                    intent.putExtra("customer_address", customerAddress);
                                    intent.putExtra("customer_phone", customerPhone);
                                    intent.putExtra("date", date);
                                    intent.putExtra("time", time);
                                    startActivityForResult(intent, 1);
                                    AlertDialog.Builder ratingDialogBuilder = new AlertDialog.Builder(MainActivity8.this);
                                    ratingDialogBuilder.setTitle("Rate this provider");


                                    LayoutInflater inflater = getLayoutInflater();
                                    View dialogView = inflater.inflate(R.layout.rating_dialogue, null);
                                    RatingBar updateRatingBar = dialogView.findViewById(R.id.update_rating_bar);
                                    updateRatingBar.setNumStars(5);
                                    updateRatingBar.setStepSize(0.5f);
                                    updateRatingBar.setRating(provider.getRating());

                                    ratingDialogBuilder.setView(dialogView);
                                    ratingDialogBuilder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            float newRating = updateRatingBar.getRating();

                                            dbHelper.updateRating(provider.getId(), newRating);

                                            provider.setRating(newRating);

                                            ratingBar.setRating(newRating);

                                            Toast.makeText(MainActivity8.this, "Rating updated successfully!", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                    ratingDialogBuilder.setNegativeButton("Cancel", null);
                                    ratingDialogBuilder.create().show();
                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            })
                            .create()
                            .show();
                }
            });
        }
    }


    private byte[] getBytesFromDrawable(Drawable drawable) {
        Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }
}
