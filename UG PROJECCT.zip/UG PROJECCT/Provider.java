package com.example.home;
public class Provider {
    private int id;
    private String name;
    private String brand;
    private int imageResourceId;
    private String phoneNumber;
    private int rating;

    public Provider() {
    }

    public Provider(int id, String name, String brand, int imageResourceId, String phoneNumber, int rating) {
        this.id = id;
        this.name = name;
        this.brand = brand;
        this.imageResourceId = imageResourceId;
        this.phoneNumber = phoneNumber;
        this.rating = rating;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }

    public void setImageResourceId(int imageResourceId) {
        this.imageResourceId = imageResourceId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}
