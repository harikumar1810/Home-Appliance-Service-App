package com.example.home;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity6 extends AppCompatActivity {
    Button button2;
    RadioGroup providers_group;
    RadioButton radioButton, radioButton1;
    EditText editTextDate2, editTextTime;
    Calendar c2;
    DatePickerDialog dpd2;

    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity6_main);
        button2 = findViewById(R.id.button2);
        editTextDate2 = findViewById(R.id.editTextDate2);
        editTextTime = findViewById(R.id.editTextTime);
        providers_group = findViewById(R.id.providers_group);
        radioButton = findViewById(R.id.radioButton);
        radioButton1 = findViewById(R.id.radioButton1);
        dbHelper = new DBHelper(MainActivity6.this);

        editTextDate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c2 = Calendar.getInstance();
                int day = c2.get(Calendar.DAY_OF_MONTH);
                int month = c2.get(Calendar.MONTH);
                int year = c2.get(Calendar.YEAR);

                dpd2 = new DatePickerDialog(MainActivity6.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        editTextDate2.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
                    }
                }, year, month, day);
                dpd2.show();
            }
        });

        editTextTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showTimePickerDialog();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addCustomer();
            }
        });
    }

    private void showTimePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String time = String.format("%02d:%02d", hourOfDay, minute);
                editTextTime.setText(time);
            }
        }, hour, minute, true);
        timePickerDialog.show();
    }
    private void addCustomer() {
        try {
            int selectedId = providers_group.getCheckedRadioButtonId();
            if (selectedId != -1) {
                radioButton = findViewById(selectedId);
                String provider = radioButton.getText().toString();
                Toast.makeText(MainActivity6.this, "Provider: " + provider, Toast.LENGTH_SHORT).show();

                String date = editTextDate2.getText().toString();
                String time = editTextTime.getText().toString();
                dbHelper.addNewCustomer(date, time, provider);
                Toast.makeText(this, "Customer added successfully", Toast.LENGTH_SHORT).show();

                editTextDate2.setText("");
                editTextTime.setText("");


                Intent intent;
                if (provider.equalsIgnoreCase("Special Providers")) {
                    intent = new Intent(MainActivity6.this, MainActivity7.class);
                    startActivity(intent);
                } else if (provider.equalsIgnoreCase("Generic Providers")) {
                    intent = new Intent(MainActivity6.this, MainActivity8.class);
                    startActivity(intent);
                } else {

                    intent = new Intent(MainActivity6.this, MainActivity6.class);
                    startActivity(intent);
                }
            }
        } catch (Exception e) {

            e.printStackTrace();
            Toast.makeText(this, "An error occurred: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

}