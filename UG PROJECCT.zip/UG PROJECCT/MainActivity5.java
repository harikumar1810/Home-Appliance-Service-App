package com.example.home;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity5 extends AppCompatActivity {
    private EditText editTextText3, editTextText2, editTextPhone, editTextText, editTextDate;
    private Button button;
    private CheckBox checkBox, checkBox2;
    TextView textViewDate, textViewSerialNo;
    private DatePickerDialog datePickerDialog;
    private Calendar calendar;
    private DBHelper dbHelper;
    private String warrantyStatus = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity5_main);

        editTextText2 = findViewById(R.id.editTextText2);
        editTextText3 = findViewById(R.id.editTextText3);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextDate = findViewById(R.id.editTextDate);
        editTextText = findViewById(R.id.editTextText);
        button = findViewById(R.id.button);
        checkBox = findViewById(R.id.checkBox);
        checkBox2 = findViewById(R.id.checkBox2);
        textViewDate = findViewById(R.id.textView11);
        textViewSerialNo = findViewById(R.id.textView2);
        dbHelper = new DBHelper(MainActivity5.this);

        editTextDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkBox2.setChecked(false);
                    editTextText.setVisibility(View.VISIBLE);
                    editTextDate.setVisibility(View.VISIBLE);
                    warrantyStatus = "inwarranty";
                } else {
                    editTextText.setVisibility(View.GONE);
                    editTextDate.setVisibility(View.GONE);
                    warrantyStatus = "";
                }
            }
        });

        checkBox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkBox.setChecked(false);
                    editTextText.setVisibility(View.GONE);
                    editTextDate.setVisibility(View.GONE);
                    warrantyStatus = "outofwarranty";
                }
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerCustomer();
            }
        });
    }

    private void showDatePickerDialog() {
        calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH);
        int year = calendar.get(Calendar.YEAR);

        datePickerDialog = new DatePickerDialog(MainActivity5.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String date = dayOfMonth + "/" + (month + 1) + "/" + year;
                editTextDate.setText(date);
            }
        }, year, month, day);
        datePickerDialog.show();
    }

    private void registerCustomer() {
        String name = editTextText2.getText().toString();
        String address = editTextText3.getText().toString();
        String phone = editTextPhone.getText().toString();
        String dateOfPurchase = editTextDate.getText().toString();
        String serialNoProduct = editTextText.getText().toString();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(address)) {
            Toast.makeText(MainActivity5.this, "Please enter your name and address", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(phone)) {
            Toast.makeText(MainActivity5.this, "Enter phone number", Toast.LENGTH_SHORT).show();
        } else if (phone.length() != 10) {
            Toast.makeText(MainActivity5.this, "Phone number should be 10 digits", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(dateOfPurchase) && !checkBox2.isChecked()) {
            editTextDate.setError("Please enter date of purchase");
        } else if (TextUtils.isEmpty(serialNoProduct) && !checkBox2.isChecked()) {
            Toast.makeText(MainActivity5.this, "Enter serial number", Toast.LENGTH_SHORT).show();
        } else {
            dbHelper.addNewCustomer(name, address, phone, dateOfPurchase, serialNoProduct, warrantyStatus);
            Toast.makeText(MainActivity5.this, "Registered successfully", Toast.LENGTH_SHORT).show();
            editTextText2.setText("");
            editTextText3.setText("");
            editTextPhone.setText("");
            editTextDate.setText("");
            editTextText.setText("");

            Intent intent = new Intent(MainActivity5.this, MainActivity6.class);
            startActivity(intent);
        }
    }

}
