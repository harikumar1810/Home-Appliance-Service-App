package com.example.home;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class MainActivity10 extends AppCompatActivity {

    private EditText nameEditText, addressEditText, cityEditText, phoneNumberEditText,genemail,genpassword;
    private ImageView imageView;
    private Button submitButton, addImageButton;
    private DBHelper dbHandler;
    private static final int PICK_IMAGE_REQUEST = 1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity10_main);

        nameEditText = findViewById(R.id.editTextText4);
        addressEditText = findViewById(R.id.editTextText5);
        cityEditText = findViewById(R.id.editTextText7);
        phoneNumberEditText = findViewById(R.id.editTextText6);
        imageView = findViewById(R.id.imageView);
        submitButton = findViewById(R.id.button3);
        addImageButton = findViewById(R.id.button4);
        genemail=findViewById(R.id.edit8);
        genpassword=findViewById(R.id.edit9);

        dbHandler = new DBHelper(this);

        addImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImageGallery();
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString();
                String address = addressEditText.getText().toString();
                String city = cityEditText.getText().toString();
                String phoneNumber = phoneNumberEditText.getText().toString();
                String email = genemail.getText().toString();
                String password = genpassword.getText().toString();

                Bitmap bitmap = null;
                BitmapDrawable drawable = (BitmapDrawable) imageView.getDrawable();
                if (drawable != null) {
                    bitmap = drawable.getBitmap();
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    byte[] imageBytes = stream.toByteArray();


                    dbHandler.insertGenericProviderData(name, address, city, phoneNumber, imageBytes,0,email,password);


                    Toast.makeText(MainActivity10.this, "registered successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity10.this, MainActivity.class);
                    startActivity(intent);
                }
                else if (!isStrongPassword(password)) {
                    Toast.makeText(MainActivity10.this, "Password should be at least 8 characters long and include a mix of letters, numbers, and symbols", Toast.LENGTH_LONG).show();
                }
                else {

                    Toast.makeText(MainActivity10.this, "Please fill all details", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private boolean isStrongPassword(String password) {

        return password.length() >= 8 && password.matches("^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[@#$%^&+=]).*$");
    }
    private void openImageGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri imageUri = data.getData();
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);


                int maxSize = 200;
                int width = bitmap.getWidth();
                int height = bitmap.getHeight();
                float ratio = (float) width / height;
                if (width > height) {
                    width = maxSize;
                    height = (int) (width / ratio);
                } else {
                    height = maxSize;
                    width = (int) (height * ratio);
                }
                bitmap = Bitmap.createScaledBitmap(bitmap, width, height, true);


                imageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
