package com.example.home;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SearchView;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;


public class MainActivity3 extends AppCompatActivity {

    Map<String, Integer> productImageMap = new HashMap<>();
    Map<String, Integer> productTextViewMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity3_main);

        productImageMap.put("Air conditioner", R.id.imageButton2);
        productImageMap.put("Water purifier", R.id.imageButton3);
        productImageMap.put("Refrigerator", R.id.imageButton4);
        productImageMap.put("Chimney", R.id.imageButton5);
        productImageMap.put("Fan", R.id.imageButton6);
        productImageMap.put("TV", R.id.imageButton7);
        productImageMap.put("Washing machine", R.id.imageButton8);
        productImageMap.put("Microwave", R.id.imageButton9);

        productTextViewMap.put("Air conditioner", R.id.textView);
        productTextViewMap.put("Water purifier", R.id.textView3);
        productTextViewMap.put("Refrigerator", R.id.textView4);
        productTextViewMap.put("Chimney", R.id.textView5);
        productTextViewMap.put("Fan", R.id.textView2);
        productTextViewMap.put("TV", R.id.textView6);
        productTextViewMap.put("Washing machine", R.id.textView8);
        productTextViewMap.put("Microwave", R.id.textView9);

        SearchView searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterProduct(newText);
                return true;
            }
        });

        showAllProducts();
    }

    private void filterProduct(String query) {
        for (Map.Entry<String, Integer> entry : productImageMap.entrySet()) {
            String product = entry.getKey();
            Integer imageButtonId = entry.getValue();
            Integer textViewId = productTextViewMap.get(product);
            if (imageButtonId != 0 && textViewId != null) {
                ImageButton imageButton = findViewById(imageButtonId);
                TextView textView = findViewById(textViewId);
                if (product.toLowerCase().contains(query.toLowerCase())) {
                    imageButton.setVisibility(View.VISIBLE);
                    textView.setVisibility(View.VISIBLE);
                    imageButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(MainActivity3.this, MainActivity4.class);
                            intent.putExtra("product_name", product);
                            startActivity(intent);
                        }
                    });
                } else {
                    imageButton.setVisibility(View.GONE);
                    textView.setVisibility(View.GONE);
                }
            }
        }
    }

    private void showAllProducts() {
        for (Map.Entry<String, Integer> entry : productImageMap.entrySet()) {
            Integer imageButtonId = entry.getValue();
            Integer textViewId = productTextViewMap.get(entry.getKey());
            if (imageButtonId != 0 && textViewId != null) {
                ImageButton imageButton = findViewById(imageButtonId);
                TextView textView = findViewById(textViewId);
                if (imageButton != null && textView != null) {
                    imageButton.setVisibility(View.VISIBLE);
                    textView.setVisibility(View.VISIBLE);
                    imageButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(MainActivity3.this, MainActivity4.class);
                            intent.putExtra("product_name", entry.getKey());
                            startActivity(intent);
                        }
                    });
                }
            }
        }
    }
}
