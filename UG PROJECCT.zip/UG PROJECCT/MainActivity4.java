package com.example.home;

import androidx.appcompat.app.AppCompatActivity;


import android.view.View;
import android.widget.ImageButton;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity4 extends AppCompatActivity {
    ImageButton ib1,ib2,ib3,ib4,ib5,ib6,ib7,ib8;
    DBHelper dbhelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity4_main);
        ib1 = findViewById(R.id.ib1);
        ib2= findViewById(R.id.ib2);
        ib3 = findViewById(R.id.ib3);
        ib4 = findViewById(R.id.ib4);
        ib5 = findViewById(R.id.ib5);
        ib6 = findViewById(R.id.ib6);
        ib7 = findViewById(R.id.ib7);
        ib8= findViewById(R.id.ib8);
        dbhelper = new DBHelper(this);



        ib1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), MainActivity3.class);
                String productName = getIntent().getStringExtra("product_name");
                dbhelper.insertData(productName,"Haier");
                startActivity(i);
                Intent intent = new Intent(MainActivity4.this, MainActivity5.class);
                startActivity(intent);
            }
        });
        ib2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), MainActivity2.class);
                String productName = getIntent().getStringExtra("product_name");
                dbhelper.insertData(productName,"Samsung");
                startActivity(i);
                Intent intent = new Intent(MainActivity4.this, MainActivity5.class);
                startActivity(intent);
            }
        }); ib3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), MainActivity2.class);
                String productName = getIntent().getStringExtra("product_name");
                dbhelper.insertData(productName,"Gogrej");
                startActivity(i);
                Intent intent = new Intent(MainActivity4.this, MainActivity5.class);
                startActivity(intent);
            }
        });
        ib4.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), MainActivity2.class);
                String productName = getIntent().getStringExtra("product_name");
                dbhelper.insertData(productName,"Voltas");
                startActivity(i);
                Intent intent = new Intent(MainActivity4.this, MainActivity5.class);
                startActivity(intent);
            }
        });
        ib5.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), MainActivity2.class);
                String productName = getIntent().getStringExtra("product_name");
                dbhelper.insertData(productName,"Bajaj");
                startActivity(i);
                Intent intent = new Intent(MainActivity4.this, MainActivity5.class);
                startActivity(intent);
            }
        });
        ib6.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), MainActivity2.class);
                String productName = getIntent().getStringExtra("product_name");
                dbhelper.insertData(productName,"Hitachi");
                startActivity(i);
                Intent intent = new Intent(MainActivity4.this, MainActivity5.class);
                startActivity(intent);
            }
        });
        ib7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), MainActivity2.class);
                String productName = getIntent().getStringExtra("product_name");
                dbhelper.insertData(productName,"LG");
                startActivity(i);
                Intent intent = new Intent(MainActivity4.this, MainActivity5.class);
                startActivity(intent);
            }
        });
        ib8.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), MainActivity2.class);
                String productName = getIntent().getStringExtra("product_name");
                dbhelper.insertData(productName,"Bluestar");
                startActivity(i);
                Intent intent = new Intent(MainActivity4.this, MainActivity5.class);
                startActivity(intent);
            }
        });
    }}


