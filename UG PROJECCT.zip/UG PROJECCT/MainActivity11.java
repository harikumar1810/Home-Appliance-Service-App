package com.example.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity11 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity11_main);


        Intent intent = getIntent();
        String providerName = intent.getStringExtra("provider_name");
        String providerPhone = intent.getStringExtra("provider_phone");
        String customerName = intent.getStringExtra("customer_name");
        String customerAddress = intent.getStringExtra("customer_address");
        String customerPhone = intent.getStringExtra("customer_phone");
        String date = intent.getStringExtra("date");
        String time = intent.getStringExtra("time");


        TextView providerNameTextView = findViewById(R.id.provider_name_text_view);
        providerNameTextView.setText("Provider Name: " + providerName);

        TextView providerPhoneTextView = findViewById(R.id.provider_phone_text_view);
        providerPhoneTextView.setText("Provider Phone: " + providerPhone);

        TextView customerNameTextView = findViewById(R.id.customer_name_text_view);
        customerNameTextView.setText("Customer Name: " + customerName);

        TextView customerAddressTextView = findViewById(R.id.customer_address_text_view);
        customerAddressTextView.setText("Customer Address: " + customerAddress);

        TextView customerPhoneTextView = findViewById(R.id.customer_phone_text_view);
        customerPhoneTextView.setText("Customer Phone: " + customerPhone);

        TextView dateTextView = findViewById(R.id.date_text_view);
        dateTextView.setText("Date: " + date);

        TextView timeTextView = findViewById(R.id.time_text_view);
        timeTextView.setText("Time: " + time);

        Button confirmButton = findViewById(R.id.confirm_button);
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent resultIntent = new Intent();
                resultIntent.putExtra("result", "confirmed");
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });

        Button deleteButton = findViewById(R.id.delete_button);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("result", "deleted");
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }
}
