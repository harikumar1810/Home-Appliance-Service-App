package com.example.home;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "smartservice_db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_MOBILE = "mobile";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_PRODUCT_NAME = "product_name";
    private static final String COLUMN_BRAND = "brand";
    private static final String TABLE_APPOINTMENT = "customer_appointment";
    private static final String ID_COL = "id";
    private static final String NAME_COL = "name";
    private static final String ADDRESS_COL = "address";
    private static final String PHONE_COL = "phone";
    private static final String DATE_OF_PURCHASE_COL = "date_of_purchase";
    private static final String SERIAL_NO_PRODUCT_COL = "serial_no_product";
    private static final String WARRANTY_STATUS = "warranty_status";

    private static final String Date = "date";

    private static final String Time= "time";

    private static final String Provider = "provider";

    private static final String BRAND = "brand";
    private static final String COLUMN_IMAGE_RESOURCE_ID = "image_resource_id";
    private static final String COLUMN_PHONE_NUMBER = "phone_number";
    private static final String COLUMN_RATING = "rating";
    private static final String TABLEE_NAME = "generic_providers";
    private static final String TABLE_PROVIDERS = "providers";

    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_BRAND = "brand";
    private static final String KEY_IMAGE_RESOURCE_ID = "image_resource_id";
    private static final String KEY_PHONE_NUMBER = "phone_number";
    private static final String KEY_RATING = "rating";
    private static final String KEY_STATUS = "status";
    private static final String KEY_SERVICER_NAME = "servicerName";
    private static final String KEY_SERVICER_BRAND = "servicerBrand";

    private static final String KEY_SERVICER_PHONE_NUMBER = "servicerPhoneNumber";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT, "
                + COLUMN_MOBILE + " TEXT, "
                + COLUMN_EMAIL + " TEXT, "
                + COLUMN_PASSWORD + " TEXT, "
                + COLUMN_PRODUCT_NAME + " TEXT, "
                + COLUMN_BRAND + " TEXT"
                + ")";
        db.execSQL(CREATE_TABLE);

        String CREATE_CUSTOMER_FORM_TABLE = "CREATE TABLE " + TABLE_APPOINTMENT + "("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + NAME_COL + " TEXT,"
                + ADDRESS_COL + " TEXT,"
                + PHONE_COL + " TEXT,"
                + DATE_OF_PURCHASE_COL + " TEXT,"
                + SERIAL_NO_PRODUCT_COL + " TEXT,"
                + WARRANTY_STATUS + " TEXT,"
                + Date + " TEXT,"
                + Time + " TEXT,"
                + Provider + " TEXT"
                +KEY_STATUS+"TEXT"
                +KEY_SERVICER_NAME+"TEXT"
                +KEY_BRAND+"TEXT"
                +KEY_PHONE_NUMBER+"TEXT"
                + ")";
        db.execSQL(CREATE_CUSTOMER_FORM_TABLE);


        String CREATE_GENERIC_TABLE = "CREATE TABLE " + TABLEE_NAME + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "rating REAL," +
                "image BLOB," +
                "phone_number TEXT," +
                "address TEXT," +
                "city TEXT," +
                "email TEXT," +
                "password TEXT)";

        db.execSQL(CREATE_GENERIC_TABLE);

        String CREATE_PROVIDERS_TABLE = "CREATE TABLE " + TABLE_PROVIDERS + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_NAME + " TEXT,"
                + KEY_BRAND + " TEXT,"
                + KEY_IMAGE_RESOURCE_ID + " INTEGER,"
                + KEY_PHONE_NUMBER + " TEXT,"
                + KEY_RATING + " INTEGER" + ")";
        db.execSQL(CREATE_PROVIDERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_APPOINTMENT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROVIDERS);
        db.execSQL("DROP TABLE IF EXISTS " +TABLEE_NAME);
        onCreate(db);
    }

    public boolean addUser(String username, String mobile, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_MOBILE, mobile);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_NAME, null, values);
        return result != -1;
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_ID};
        String selection = COLUMN_EMAIL + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {email, password};
        Cursor cursor = db.query(TABLE_NAME, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }



    public void insertData(String product_name, String brand_selected) {
        SQLiteDatabase mydb = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_PRODUCT_NAME, product_name);
        cv.put(COLUMN_BRAND, brand_selected);
        mydb.insert(TABLE_NAME, null, cv);
        mydb.close();
    }

    public void addNewCustomer(String name, String address, String phone, String dateOfPurchase, String serialNoProduct,String warrentystatus) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NAME_COL, name);
        values.put(ADDRESS_COL, address);
        values.put(PHONE_COL, phone);
        values.put(DATE_OF_PURCHASE_COL, dateOfPurchase);
        values.put(SERIAL_NO_PRODUCT_COL, serialNoProduct);
        values.put(WARRANTY_STATUS, warrentystatus);
        db.insert(TABLE_APPOINTMENT, null, values);
        db.close();
    }

    public void addNewCustomer(String date, String time, String provider) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Date, date);
        values.put(Time, time);
        values.put(Provider, provider);
        db.insert(TABLE_APPOINTMENT, null, values);
        db.close();
    }

    public void addbooking(String status, String servicerName, String servicerBrand, String servicerPhoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(KEY_STATUS, status);
        values.put(KEY_SERVICER_NAME, servicerName);
        values.put(KEY_SERVICER_BRAND, servicerBrand);
        values.put(KEY_SERVICER_PHONE_NUMBER, servicerPhoneNumber);

        db.insert(TABLE_APPOINTMENT, null, values);
        db.close();
    }


    public void insertGenericProviderData(String name, String address, String city, String phoneNumber, byte[] image, float rating, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("address", address);
        values.put("city", city);
        values.put("phone_number", phoneNumber);
        values.put("image", image);
        values.put("rating", rating);
        values.put("email", email);
        values.put("password", password);
        db.insert("generic_providers", null, values);
        db.close();
    }

    public boolean validateLogin(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {"id"};
        String selection = "email = ? AND password = ?";
        String[] selectionArgs = {email, password};
        Cursor cursor = db.query("generic_providers", columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();
        return count > 0;
    }



    public void addProvider(String name, String brand, int imageResourceId, String phoneNumber, int rating) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, name);
        values.put(KEY_BRAND, brand);
        values.put(KEY_IMAGE_RESOURCE_ID, imageResourceId);
        values.put(KEY_PHONE_NUMBER, phoneNumber);
        values.put(KEY_RATING, rating);

        db.insert(TABLE_PROVIDERS, null, values);
        db.close();
    }

    public List<Provider> getAllProvider() {
        List<Provider> providerList = new ArrayList<>();
        String selectQuery = "SELECT  * FROM " + TABLE_PROVIDERS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Provider provider = new Provider();
                provider.setId(Integer.parseInt(cursor.getString(0)));
                provider.setName(cursor.getString(1));
                provider.setBrand(cursor.getString(2));
                provider.setImageResourceId(Integer.parseInt(cursor.getString(3)));
                provider.setPhoneNumber(cursor.getString(4));
                provider.setRating(Integer.parseInt(cursor.getString(5)));

                providerList.add(provider);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return providerList;
    }



    public void updateRating(int id, float newRating) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("rating", newRating);
        db.update("generic_providers", values, "id=?", new String[]{String.valueOf(id)});
        db.close();
    }

    public List<Provider2> getAllProviders() {
        List<Provider2> providersList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {
                "id",
                "name",
                "phone_number",
                "rating",
                "image"
        };

        Cursor cursor = db.query(
                "generic_providers",
                projection,
                null,
                null,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
            String phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow("phone_number"));
            float rating = cursor.getFloat(cursor.getColumnIndexOrThrow("rating"));
            byte[] image = cursor.getBlob(cursor.getColumnIndexOrThrow("image"));

            Provider2 provider = new Provider2(id, name, phoneNumber, image, rating);

            providersList.add(provider);
        }

        cursor.close();
        return providersList;
    }


}
