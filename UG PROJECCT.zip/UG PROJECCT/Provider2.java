package com.example.home;
public class Provider2 {
    private int id;
    private String name;
    private String phoneNumber;
    private byte[] image;
    private float rating;

    public Provider2(int id, String name, String phoneNumber, byte[] image, float rating) {
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.image = image;
        this.rating = rating;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public byte[] getImage() {
        return image;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }
}
