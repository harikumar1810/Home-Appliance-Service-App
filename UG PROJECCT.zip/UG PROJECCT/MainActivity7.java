package com.example.home;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity7 extends AppCompatActivity {
    SearchView searchView;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity7_main);

        dbHelper = new DBHelper(this);


        dbHelper.addProvider("Servicer1", "Voltas", R.drawable.pp1, "1234567890", 4);
        dbHelper.addProvider("Servicer2", "Haier", R.drawable.pp1, "9876543210", 5);
        dbHelper.addProvider("Servicer3", "LG", R.drawable.pp1, "1231231234", 3);



        List<Provider> providerList = dbHelper.getAllProvider();




        LinearLayout row1 = findViewById(R.id.row1);
        LinearLayout row2 = findViewById(R.id.row2);
        LinearLayout row3 = findViewById(R.id.row3);

        for (Provider provider : providerList) {
            CardView cardView = new CardView(this);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            cardParams.setMargins(10, 10, 10, 10);
            cardView.setLayoutParams(cardParams);

            cardView.setCardElevation(8);
            cardView.setRadius(16);

            LinearLayout cardLayout = new LinearLayout(this);
            cardLayout.setOrientation(LinearLayout.VERTICAL);

            ImageView imageView = new ImageView(this);
            LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 300);
            imageView.setLayoutParams(imageParams);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setImageResource(provider.getImageResourceId());

            TextView textView1 = new TextView(this);
            LinearLayout.LayoutParams text1Params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            textView1.setLayoutParams(text1Params);
            textView1.setText(provider.getName());
            textView1.setTextSize(25);
            textView1.setGravity(Gravity.CENTER);
            textView1.setTypeface(null, android.graphics.Typeface.BOLD);

            TextView textView2 = new TextView(this);
            LinearLayout.LayoutParams text2Params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            textView2.setLayoutParams(text2Params);
            textView2.setText(provider.getBrand() + " - " + provider.getPhoneNumber());
            textView2.setTextSize(20);
            textView2.setGravity(Gravity.CENTER);

            cardLayout.addView(imageView);
            cardLayout.addView(textView1);
            cardLayout.addView(textView2);

            cardView.addView(cardLayout);

            if (row1.getChildCount() < 1) {
                row1.addView(cardView);
            } else if (row2.getChildCount() < 1) {
                row2.addView(cardView);
            } else {
                row3.addView(cardView);
            }



            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity7.this);
                    builder.setMessage("Do you want to book?")
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Toast.makeText(MainActivity7.this, "booked successful", Toast.LENGTH_SHORT).show();
                                    dbHelper.addbooking("booked",provider.getName(),provider.getBrand(),provider.getPhoneNumber());
                                    Intent intent = new Intent(MainActivity7.this, MainActivity3.class);
                                    startActivity(intent);

                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            })
                            .create()
                            .show();
                }
            });
        }
    }
}
