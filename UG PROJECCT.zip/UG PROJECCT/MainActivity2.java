package com.example.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText mobileEditText;
    private EditText emailEditText;
    private EditText passwordEditText;
    private Button signUpButton;

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2_main);

        usernameEditText = findViewById(R.id.editTextText);
        mobileEditText = findViewById(R.id.editTextText2);
        emailEditText = findViewById(R.id.editTextText3);
        passwordEditText = findViewById(R.id.editTextText4);
        signUpButton = findViewById(R.id.button4);
        dbHelper=new DBHelper(this);

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String mobile = mobileEditText.getText().toString();
                String email = emailEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                try {
                    if (username.isEmpty() || mobile.isEmpty() || email.isEmpty() || password.isEmpty()) {
                        Toast.makeText(MainActivity2.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    } else if (!isStrongPassword(password)) {
                        Toast.makeText(MainActivity2.this, "Password should be at least 8 characters long and include a mix of letters, numbers, and symbols", Toast.LENGTH_LONG).show();
                    } else if (mobile.length() != 10) {
                        Toast.makeText(MainActivity2.this, "Phone number should be 10 digits", Toast.LENGTH_SHORT).show();
                    } else {
                        boolean success = dbHelper.addUser(username, mobile, email, password);
                        if (success) {
                            Toast.makeText(getApplicationContext(), "Sign up successful", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(getApplicationContext(), "Sign up failed", Toast.LENGTH_SHORT).show();
                        }
                    }

                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), ex.getMessage().toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isStrongPassword(String password) {
        return password.length() >= 8 && password.matches("^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[@#$%^&+=]).*$");
    }
}
